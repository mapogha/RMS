<?php
// Include logic file
require_once '../backend/view-payments-by-date.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Payments</title>
</head>
<body>

    <!-- HTML form to input date -->
    <form method="post" action="">
        <label for="date">Enter Date:</label>
        <input type="date" id="date" name="date">
        <button type="submit">View Payments</button>
    </form>

    <?php if(isset($_POST['date'])): ?>
        <?php 
        // Get the date from the form submission
        $date = $_POST['date'];

        // Fetch payments for the specified date
        $payments = fetchPaymentsByDate($conn, $date);
        ?>
        <?php if($payments): ?>
            <!-- Display payments -->
            <h2>Payments for Date: <?= $date ?></h2>
            <table border='1'>
                <tr>
                    <th>S/N</th>
                    <th>Owner Name</th> <!-- Add new column -->
                    <th>Plate Number</th> <!-- Add new column -->
                    <th>Payment Date</th>
                </tr>
                <?php $serialNumber = 1; ?>
                <?php foreach($payments as $payment): ?>
                    <tr>
                        <td><?= $serialNumber++ ?></td>
                        <td><?= $payment['ownerName'] ?></td> <!-- Display ownerName -->
                        <td><?= $payment['plateNumber'] ?></td> <!-- Display plateNumber -->
                        <td><?= $payment['payment_date'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
        <?php else: ?>
            <p>No payments found for the specified date.</p>
        <?php endif; ?>
    <?php endif; ?>

</body>
</html>
