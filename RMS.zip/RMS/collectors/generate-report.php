<?php
include'../backend/payment-amount.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="amount-perday">
        <h2>Calculate Total Amount Per Day</h2>
        <form method="post" action="../backend/payment-amount.php">
            <label for="date">Date:</label>
            <input type="date" id="date" name="date" required>
            <button type="submit">Calculate</button>
        </form>
        
        <?php if(isset($totalAmount)): ?>
            <h3>Total amount obtained on <?php echo $date; ?>: $<?php echo number_format($totalAmount, 2); ?></h3>
        <?php endif; ?>
        
        <?php if(isset($error)): ?>
            <p><?php echo $error; ?></p>
        <?php endif; ?>
    </div>
</body>
</html>