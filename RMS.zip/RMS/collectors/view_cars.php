<?php
// session_start();

include'../backend/view-cars.php';
// include'../backend/confirm-payment.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        #customers {
        font-family: Arial, Helvetica, sans-serif;
        border-collapse: collapse;
        width: 100%;
        }

        #customers td, #customers th {
        border: 1px solid #ddd;
        padding: 8px;
        }

        #customers tr:nth-child(even){background-color: #f2f2f2;}

        #customers tr:hover {background-color: #ddd;}

        #customers th {
        padding-top: 12px;
        padding-bottom: 12px;
        text-align: left;
        background-color: #4CAF50;
        color: white;
        }
        .highlight {
            background-color: yellow;
            font-weight: bold;
        }
        #noResultsMessage {
            display: none;
            color: red;
            font-style: italic;
        }
        .success{
            color: green;
        }
        .failure{
            color: red;
        }
    </style>
</head>
<body>
    <div class="view-main">
        <input type="text" id="plateNumberInput" placeholder="Enter Plate Number">
        <br><br>
        <?php
            if(isset($_SESSION['payment'])){
                echo $_SESSION['payment'];
                unset($_SESSION['payment']);
            }
        ?>
        <table id="customers">
            <tr>
                <th>S/N</th>
                <th>Owner Name</th>
                <th>Phone NUmber</th>
                <th>Plate Number</th>
                <th>Actions</th>
            </tr>

            <?php
                $i=1;
                foreach($cars as $car){
                    ?>
                        <tr>
                            <td><?=$i?></td>
                            <td><?=$car['ownerName']?></td>
                            <td><?=$car['phoneNumber']?></td>
                            <td><?=$car['plateNumber']?></td>
                            <td>
                                <a href="view_car_details.php?id=<?=$car['id']?>">View</a>
                                <a href="../backend/confirm-payment.php?id=<?=$car['id']?>">Payed</a>
                            </td>
                        </tr>
                    <?php
                    $i++;
                }
            ?>

        
            
            
        
        
        </table>
    </div>


    <script>
        var input = document.getElementById("plateNumberInput");
        var table = document.getElementById("customers");
        var noResultsMessage = document.getElementById("noResultsMessage");

        input.addEventListener("input", function() {
            var filter = input.value.toUpperCase();
            var rows = table.getElementsByTagName("tr");
            var found = false;

            for (var i = 1; i < rows.length; i++) {
                var plateNumberCell = rows[i].getElementsByTagName("td")[3];
                if (plateNumberCell) {
                    var plateNumberValue = plateNumberCell.textContent || plateNumberCell.innerText;
                    if (plateNumberValue.toUpperCase().indexOf(filter) > -1) {
                        rows[i].style.display = "";
                        if (filter !== "") {
                            var regExp = new RegExp(filter, 'gi');
                            var replacedText = plateNumberValue.replace(regExp, function(match) {
                                return '<span class="highlight">' + match + '</span>';
                            });
                            plateNumberCell.innerHTML = replacedText;
                        } else {
                            plateNumberCell.innerHTML = plateNumberValue;
                        }
                        found = true;
                    } else {
                        rows[i].style.display = "none";
                    }
                }
            }

            if (!found) {
                noResultsMessage.style.display = "block";
            } else {
                noResultsMessage.style.display = "none";
            }
        });
    </script>
</body>
</html>