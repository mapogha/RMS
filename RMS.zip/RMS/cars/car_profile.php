<?php
include'../backend/view-car.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .body-card{
            display: flex;
            justify-content: center;
        }
        form{
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            width: 30%;
        }
        input{
            padding: 3px 3px 3px 3px;
            border-radius: 10px;
        }
        .error{
            color: red;
        }
        .text-center{
            text-align: center;
        }
        .success{
            color: green;
        }
        .failure{
            color: red;
        }
    </style>
</head>
<body>
    <div class="body-card">
        <form action="../backend/update-car.php" method="post">
            <?php
                if(isset($_SESSION['update'])){
                    echo $_SESSION['update'];
                    unset($_SESSION['update']);
                }
            ?>
            <label for="ownerName">Owner's name</label>
            <input type="text" name="ownerName" id="ownerName" value="<?php echo isset($carData['ownerName']) ? $carData['ownerName'] : ''; ?>">

            <label for="carType">Car type</label>
            <input type="text" name="carType" id="carType" value="<?php echo isset($carData['carType']) ? $carData['carType'] : ''; ?>">

            <label for="phoneNumber">Phone number</label>
            <input type="tel" name="phoneNumber" id="phoneNumber" value="<?php echo isset($carData['phoneNumber']) ? $carData['phoneNumber'] : ''; ?>">

            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="<?php echo isset($carData['email']) ? $carData['email'] : ''; ?>">
            
            <label for="plateNumber">Plate Number </label>
            <input type="text" name="plateNumber" id="plateNumber" value="<?php echo isset($carData['plateNumber']) ? $carData['plateNumber'] : ''; ?>">

            <label for="route">Car's route</label>
            <input type="text" name="route" id="route" value="<?php echo isset($carData['route']) ? $carData['route'] : ''; ?>">

            <input type="submit" name="submit" value="Update Profile">
        </form>
    </div>

</body>
</html>