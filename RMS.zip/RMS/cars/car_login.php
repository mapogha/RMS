<?php
include'../backend/car-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .body-card{
            display: flex;
            justify-content: center;
        }
        form{
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            width: 30%;
        }
        input{
            padding: 3px 3px 3px 3px;
            border-radius: 10px;
        }
        .error{
            color: red;
        }
        .text-center{
            text-align: center;
        }
        .success{
            color: green;
        }
        .failure{
            color: red;
        }
    </style>
</head>
<body>
    <h2 class="text-center">LOGIN</h2>
    <div class="body-card">
        <form action="../backend/car-login.php" method="post">
            <?php
                if(isset($_SESSION['login'])){
                    echo $_SESSION['login'];
                    unset($_SESSION['login']);
                }
            ?>
            <label for="email">Enter your email</label>
            <input type="email" name="email" id="email" placeholder="youremail@gmail.com" >
            <span id="error-email" class="error"></span>

            <label for="password">Enter password</label>
            <input type="password" name="password" id="password" placeholder="@@@@@@@@">
            <span id="error-password" class="error"></span>

            <input type="submit" name="submit" value="Login">
        </form>
    </div>
</body>
</html>