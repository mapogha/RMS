<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revenue management System</title>
    <style>
        .body-card{
            display: flex;
            justify-content: center;
        }
        form{
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
            width: 30%;
        }
        input{
            padding: 3px 3px 3px 3px;
            border-radius: 10px;
        }
        .error{
            color: red;
        }
        .text-center{
            text-align: center;
        }
    </style>
</head>
<body>
    <h2 class="text-center">CAR REGISTRATION</h2>
    <div class="body-card">
        
        <form action="../backend/car-registration.php" method="post" onsubmit="return validateForm()">
            <label for="ownerName">Enter Owner's name</label>
            <input type="text" name="ownerName" id="ownerName" placeholder="Joe Nestory" autofocus>
            <span id="error-ownerName" class="error"></span>

            <label for="carType">Enter the Car type</label>
            <input type="text" name="carType" id="carType" placeholder="Mini Bus">
            <span id="error-carType" class="error"></span>

            <label for="phoneNumber">Enter your Phone number</label>
            <input type="tel" name="phoneNumber" id="phoneNumber" placeholder="+255 628 152 209">
            <span id="error-phoneNumber" class="error"></span>

            <label for="email">Enter your email</label>
            <input type="email" name="email" id="email" placeholder="youremail@gmail.com" >
            <span id="error-email" class="error"></span>
            
            <label for="plateNumber">Enter plate Number </label>
            <input type="text" name="plateNumber" id="plateNumber" placeholder="TZ 10340">
            <span id="error-plateNumber" class="error"></span>

            <label for="route">Enter Car's route</label>
            <input type="text" name="route" id="route" placeholder="Segerea - Kawe ">
            <span id="error-route" class="error"></span>

            <label for="password">Enter password</label>
            <input type="password" name="password" id="password" placeholder="@@@@@@@@">
            <span id="error-password" class="error"></span>

            <label for="cpassword">Confirm password</label>
            <input type="password" id="cpassword" placeholder="@@@@@@@@">
            <span id="error-cpassword" class="error"></span>

            <input type="submit" name="submit" value="Register">
        </form>
    </div>
    





    <script>
        function validateForm(){
            document.getElementById('error-ownerName').innerHTML="";
            document.getElementById('error-carType').innerHTML="";
            document.getElementById('error-phoneNumber').innerHTML="";
            document.getElementById('error-email').innerHTML="";
            document.getElementById('error-plateNumber').innerHTML="";
            document.getElementById('error-route').innerHTML="";
            document.getElementById('error-password').innerHTML="";
            document.getElementById('error-cpassword').innerHTML="";

            var ownerName =document.getElementById('ownerName').value;
            var carType = document.getElementById('carType').value;
            var phoneNumber = document.getElementById('phoneNumber').value;
            var email = document.getElementById('email').value;
            var plateNumber = document.getElementById('plateNumber').value;
            var route = document.getElementById('route').value;
            var password = document.getElementById('password').value;
            var Cpassword = document.getElementById('cpassword').value;

            if(ownerName ===''){
                document.getElementById('error-ownerName').innerHTML="Please enter  the owner's name";
                return false;
            }
            if(carType ===''){
                document.getElementById('error-carType').innerHTML="Please enter your car type";
                return false;
            }
            if(phoneNumber ===''){
                document.getElementById('error-phoneNumber').innerHTML="Please enter your phone number";
                return false;
            }
            if(email ===''){
                document.getElementById('error-email').innerHTML="Please enter your email";
                return false;
            }
            if(plateNumber ===''){
                document.getElementById('error-plateNumber').innerHTML="Please enter your plate number";
                return false;
            }
            if(route ===''){
                document.getElementById('error-route').innerHTML="Please enter your car's route";
                return false;
            }
            if(password ===''){
                document.getElementById('error-password').innerHTML="Please enter password";
                return false;
            }
            if(password.length<8){
                document.getElementById('error-password').innerHTML="Password must contain atlest 8 characters ";
                return false;
            }
            if(password !==Cpassword){
                document.getElementById('error-cpassword').innerHTML="Password did not match";
                return false;
            }
            
        }
    </script>
</body>
</html>