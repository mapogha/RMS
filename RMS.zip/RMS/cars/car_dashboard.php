<?php
include'../backend/car-login.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        .success{
            color: green;
        }
        .sidebar {
        height: 100%;
        width: 250px;
        position: fixed;
        top: 0;
        left: 0;
        background-color: #222;
        padding-top: 20px;
        }

        .sidebar h2 {
        color: #fff;
        text-align: center;
        }

        .sidebar ul {
        list-style-type: none;
        padding: 0;
        }

        .sidebar ul li {
        padding: 10px;
        }

        .sidebar ul li a {
        color: #fff;
        text-decoration: none;
        display: block;
        }

        .sidebar ul li a:hover {
        background-color: #555;
        }

        .content {
        margin-left: 250px;
        padding: 20px;
        }
    </style>
</head>
<body>
    <div class="dashboard-main">
        <?php
            if(isset($_SESSION['login'])){
                echo $_SESSION['login'];
                unset($_SESSION['login']);
            }
        ?>
    </div>
    <div class="sidebar">
    <h2>Dashboard</h2>
    <ul>
      <li><a href="#" class="active">Home</a></li>
      <li><a href="car_profile.php">Profile</a></li>
      <li><a href="#">Settings</a></li>
      <li><a href="#">Records</a></li>
      <li><a href="#">Logout</a></li>
    </ul>
  </div>

  <div class="content">
    <h2>Home</h2>
    <p>Welcome to your beautiful dashboard!</p>
  </div>

  <script src="../js/main.js"></script>
</body>
</html>