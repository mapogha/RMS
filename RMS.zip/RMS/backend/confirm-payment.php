<?php
// Include database connection file
require_once '../db/db.php'; // Adjust the path accordingly

// Check if car ID is provided in the URL
if(isset($_GET['id']) && !empty($_GET['id'])) {
    // Get car ID from URL
    $carID = $_GET['id'];

    // Get current date
    $date = date('Y-m-d');

    try {
        // Prepare SQL statement to insert payment details into payments table
        $stmt = $conn->prepare("INSERT INTO payments (carID, payment_date, payment_status,payment_amount) VALUES (:carID, :payment_date, 'paid','500')");

        // Bind parameters
        $stmt->bindParam(':carID', $carID);
        $stmt->bindParam(':payment_date', $date);

        // Execute the statement
        $stmt->execute();

        // Redirect to a success page or back to the previous page
        header("Location: ../collectors/view_cars.php");
        $_SESSION['payment']="<div class='success'>Payments confirmed</div>";
        exit();
    } catch(PDOException $e) {
        // Handle database errors
        echo "Error: " . $e->getMessage();
    }
} else {
    // Redirect to an error page or back to the previous page if car ID is not provided
    header("Location: ../collectors/view_cars.php");
    $_SESSION['payment']="<div class='failure'>Payments not confirmed</div>";
    exit();
}
?>
