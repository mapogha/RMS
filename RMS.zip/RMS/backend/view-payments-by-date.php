<?php
// Include database connection file
require_once '../db/db.php'; // Adjust the path as needed

// Function to fetch payments and related car information based on the specified date
function fetchPaymentsByDate($conn, $date) {
    try {
        // Prepare SQL statement to retrieve payments and related car information for the specified date
        $stmt = $conn->prepare("
            SELECT p.*, c.ownerName, c.plateNumber
            FROM payments p
            INNER JOIN cars c ON p.carID = c.id
            WHERE p.payment_date = :date
        ");
        $stmt->bindParam(':date', $date);
        $stmt->execute();
        
        // Fetch all rows
        $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return $payments;
    } catch(PDOException $e) {
        // Handle database errors
        echo "Error: " . $e->getMessage();
        return [];
    }
}
?>
