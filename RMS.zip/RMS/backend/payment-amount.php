<?php
// Include the database connection file
require_once('../db/db.php');
// Function to calculate the amount obtained per day
function calculateAmountPerDay($conn, $date) {
    try {
        // Prepare the SQL query to sum payment_amount per day
        $query = "SELECT payment_date, SUM(payment_amount) AS total_amount 
                  FROM payments 
                  WHERE payment_date = :date 
                  GROUP BY payment_date";
        $statement = $conn->prepare($query);
        
        // Bind the date parameter
        $statement->bindParam(':date', $date);
        
        // Execute the query
        $statement->execute();
        
        // Fetch the result as an associative array
        $result = $statement->fetch(PDO::FETCH_ASSOC);
        
        // Get the total amount obtained for the given date
        $totalAmount = $result['total_amount'];
        
        return $totalAmount;
    } catch (PDOException $e) {
        // If query fails, return an error message
        return "Error: " . $e->getMessage();
    }
}
?>
