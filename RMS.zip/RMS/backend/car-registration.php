<?php
include'../db/db.php';
if(isset($_POST['submit'])){
    $ownerName = $_POST['ownerName'];
    $carType =$_POST['carType'];
    $phoneNumber = $_POST['phoneNumber'];
    $email = $_POST['email'];
    $plateNumber= $_POST['plateNumber'];
    $route = $_POST['route'];
    $password=$_POST['password'];

    try{
        $sql ="insert into cars(ownerName,carType,phoneNumber,email,plateNumber,route,password) values('$ownerName','$carType','$phoneNumber','$email','$plateNumber','$route','$password')";
        $conn->exec($sql);
        header('location:../cars/car_login.php');
    }
    catch(PDOException $e){
        echo"Something wrong with registration".$e->getMessage();
    }

}
?>