<?php
    session_start();
    include '../db/db.php'; // Include database connection

    // Retrieve company ID from session
    $carId = $_SESSION['car-id'];

    // Prepare SQL statement to fetch company information
    $sql = "SELECT * FROM cars WHERE id=:carId";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':carId', $carId);
    $stmt->execute();

    $companyData = array(); // Array to store company data

    // Check if any rows are returned
    if ($stmt->rowCount() > 0) {
        // Fetch company data and store it in the $companyData array
        $carData = $stmt->fetch(PDO::FETCH_ASSOC);
    } else {
        echo "No company information found";
    }

    // Close statement and database connection
    $stmt->closeCursor();
    $conn = null;
?>
