<?php


require "../db/db.php";

$results =[];
if (isset($_GET["id"])){
    $carId = $_GET['id'];
    $sql = "Select * from cars where id = $carId";

    $statement = $conn->prepare($sql);
    $statement->execute();

    $results = $statement->fetchAll(PDO::FETCH_ASSOC);

}