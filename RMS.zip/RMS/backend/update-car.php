<?php
    session_start(); // Start the session
    include '../db/db.php'; // Include database connection

    // Check if user is logged in and session variable is set
    if(isset($_SESSION['car-id'])) {
        
        // Retrieve company ID from session
        $carId = $_SESSION['car-id'];
        
        // Check if form is submitted
        if(isset($_POST['submit'])) {
            
            // Retrieve form data
            $ownerName = $_POST['ownerName'];
            $carType = $_POST['carType'];
            $phoneNumber = $_POST['phoneNumber'];
            $email = $_POST['email'];
            $plateNumber = $_POST['plateNumber'];
            $route = $_POST['route'];
            
            try {
                // Update query
                $sql = "UPDATE cars SET
                        ownerName='$ownerName', 
                        carType=' $carType',
                        phoneNumber='$phoneNumber',
                        email='$email',
                        plateNumber='$plateNumber',
                        route=' $route'
                        WHERE id='$carId'";

                $conn->exec($sql);

                // Set success message
                $_SESSION['update'] = "<div class='success'>Profile Updated Successfully!</div>";
            } catch(PDOException $e) {
                // Set failure message with error details
                $_SESSION['update'] = "<div class='failure'>Error updating profile: " . $e->getMessage() . "</div>";
            }

            // Redirect to the company/update-cprofile.php
            header('location:../cars/car_profile.php');
            exit(); // Ensure script stops execution after redirect
        }
    } else {
        // Redirect user if not logged in or session variable not set
        echo "Invalid user ID";
        exit();
    }
?>
