<?php

include'../db/db.php';

try{
    $sql = "Select * from cars";

    $statement = $conn->prepare($sql);
    $statement->execute();
    
    $cars = $statement->fetchAll(PDO::FETCH_ASSOC);
}
catch(PDOException $e){
    echo"Error".$e->getMessage();
}

?>