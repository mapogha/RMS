<?php
// Include database connection file
// require_once '../db/db.php'; // Adjust the path as needed

// try {
    // Get the date of yesterday
    // $yesterday = date('Y-m-d', strtotime('-1 day'));

    // Prepare SQL statement to update payment status
    // $stmt = $conn->prepare("UPDATE payments SET payment_status = 'pending' WHERE payment_date = :yesterday AND payment_status = 'Paid'");

    // Bind parameter
    // $stmt->bindParam(':yesterday', $yesterday);

    // Execute the statement
//     $stmt->execute();

//     echo "Payment statuses reset successfully for payments made on $yesterday.";
// } catch(PDOException $e) {
    // Handle database errors
//     echo "Error: " . $e->getMessage();
// }
// ?>
