<?php
// Include the database connection file
require_once('../db/db.php');

// Function to get the number of registered cars
function getNumberOfRegisteredCars($conn) {
    try {
        // Prepare the SQL query to count the number of rows in the cars table
        $query = "SELECT COUNT(*) AS num_cars FROM cars";
        $statement = $conn->prepare($query);
        
        // Execute the query
        $statement->execute();
        
        // Fetch the result as an associative array
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        
        // Get the number of registered cars from the result
        $numCars = $row['num_cars'];
        
        return $numCars;
    } catch (PDOException $e) {
        // If query fails, return an error message
        return "Error: " . $e->getMessage();
    }
}

// Call the function to get the number of registered cars
try {
    $registeredCarsCount = getNumberOfRegisteredCars($conn);
    
    // Output the result
    echo "Number of registered cars: " . $registeredCarsCount;
} catch (PDOException $e) {
    // Handle any exceptions
    echo "Error: " . $e->getMessage();
}
?>
