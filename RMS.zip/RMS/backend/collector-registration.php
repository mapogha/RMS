<?php
include'../db/db.php';
if(isset($_POST['submit'])){
    $userName = $_POST['userName'];
    $phoneNumber = $_POST['phoneNumber'];
    $email = $_POST['email'];
    $password=$_POST['password'];

    try{
        $sql ="insert into collectors(userName,phoneNumber,email,password) values('$userName','$phoneNumber','$email','$password')";
        $conn->exec($sql);
        header('location:../collectors/collector_login.php');
    }
    catch(PDOException $e){
        echo"Something wrong with registration".$e->getMessage();
    }

}
?>